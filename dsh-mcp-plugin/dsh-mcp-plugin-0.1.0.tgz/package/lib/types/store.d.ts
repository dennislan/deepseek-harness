/**
 * Persistence for the MCP server store: a JSON file of mount-ready definitions.
 * A missing or corrupt file yields the empty store rather than a load failure —
 * the in-memory map stays authoritative and the next write repairs the file.
 * @module dsh-mcp-plugin/store
 */
import type { McpStore } from './types.ts';
/** The store format version this build writes. */
export declare const STORE_VERSION = 1;
/** `~/.dsh/mcp-servers.json` under `$DSH_HOME`, matching the other DSH state files. */
export declare function defaultStorePath(): string;
/**
 * Read the store from `path`. Absent or malformed files return the empty store
 * so a fresh install and a corrupted file behave identically at load time.
 * Both the native `{ version, servers }` envelope and the legacy Claude-Code
 * `{ mcpServers }` shape are accepted; legacy entries are migrated in place so
 * a user hand-written file is visible without a manual schema rewrite.
 * @param path - absolute path to the store file.
 * @returns the parsed store, or an empty one.
 */
export declare function loadStore(path: string): Promise<McpStore>;
/**
 * Write `store` to `path`, creating the parent directory. A successful write is
 * the store's commit point; callers treat the in-memory map as authoritative and
 * retry on the next change if this rejects. Native entries stay verbatim; a
 * legacy-migrated entry round-trips in the native `{ version, servers }`
 * envelope so a hand-written `mcpServers` file is normalized on first mount.
 * @param path - absolute path to the store file.
 * @param store - the complete store to persist.
 */
export declare function saveStore(path: string, store: McpStore): Promise<void>;
//# sourceMappingURL=store.d.ts.map