/**
 * Live mounting of `@deepseek-ai/dsh-mcp-client` bridges. Each stored MCP
 * server becomes a child fiber under the owning manager context: `ctx.plugin()`
 * connects it and registers its tools on `ctx.tools` under `mcp__<name>__*`.
 * Disposing the fiber tears the connection down and unregisters its tools.
 * @module dsh-mcp-plugin/mount
 */
import type { Context, Fiber } from '@deepseek-ai/cordis';
import { apply as MCP_CLIENT_APPLY } from '@deepseek-ai/dsh-mcp-client';
import type { Config as McpClientConfig } from '@deepseek-ai/dsh-mcp-client';
/** The mcp-client object plugin reused for every live mount. */
export declare const MCP_CLIENT_PLUGIN: {
    name: string;
    inject: string[];
    apply: typeof MCP_CLIENT_APPLY;
};
/** A live mcp-client fiber and the definition it was mounted with. */
export interface LiveMount {
    serverName: string;
    spec: McpClientConfig;
    fiber: Fiber;
}
/**
 * Mount one mcp-client fiber under `ctx` for `spec` and wait for its initial
 * activation. With `failOnStartupError: false` (the manager default) a downed
 * server does not reject — its reconnect loop keeps retrying in the background
 * and its tools appear once a connection succeeds.
 * @param ctx - the owning context; the child fiber unwinds when it is disposed.
 * @param spec - a mount-ready mcp-client definition.
 * @returns the live mount and its fiber.
 */
export declare function mountServer(ctx: Context, spec: McpClientConfig): Promise<LiveMount>;
/** Disconnect `mount` and unregister all of its tools. */
export declare function unmountServer(mount: LiveMount): Promise<void>;
/**
 * Count the `mcp__<serverName>__*` tools currently visible on the runtime.
 * Zero means the server has not published tools yet (not connected, or tools
 * not yet synced).
 * @param ctx - a context with the tool registry available.
 * @param serverName - the mcp-client namespace to probe.
 * @returns the number of registered tools under that namespace.
 */
export declare function toolsForServer(ctx: Context, serverName: string): number;
//# sourceMappingURL=mount.d.ts.map