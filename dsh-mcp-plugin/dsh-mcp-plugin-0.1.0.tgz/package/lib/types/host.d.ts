/**
 * Host plugin: the MCP server manager. It owns a persistent store of mcp-client
 * definitions, live-mounts a real mcp-client fiber per server so its tools are
 * callable in the running harness, and exposes four model-facing tools —
 * `mcp_list` / `mcp_add` / `mcp_modify` / `mcp_remove` — that drive the store
 * and the live connections. Persisted servers are re-mounted on load so the
 * configuration survives a restart.
 *
 * Per session, a user may prefer one managed server through the composer-dock
 * picker (the `/api/mcp/pref` routes). The preference is kept in memory and
 * reaches the model as a dynamic `mcp-server-preference` context entry on every
 * prompt assembly for that session, so sent requests steer toward that
 * server's `mcp__<serverName>__*` tools when they are needed.
 *
 * @module dsh-mcp-plugin/host
 */
import type { Context } from '@deepseek-ai/cordis';
import { Service } from '@deepseek-ai/cordis';
import z from '@deepseek-ai/schemastery';
import { type McpServerInput, type McpServerRecord } from './types.ts';
/** Deployment config for the MCP manager. */
export interface Config {
    /**
     * Where the mcp-servers store file lives. Optional; defaults to
     * `~/.dsh/mcp-servers.json` (under `$DSH_HOME`). Set this for per-profile or
     * test isolation.
     */
    storePath?: string;
}
/** Schemastery validation of {@link Config} for the loader. `storePath` is optional. */
export declare const Config: z<Schemastery.ObjectS<{
    storePath: z<string, string>;
}>, Schemastery.ObjectT<{
    storePath: z<string, string>;
}>>;
declare module '@deepseek-ai/cordis' {
    interface Context {
        mcpManager: McpManager;
    }
}
/**
 * The MCP server manager: a persistent store plus the live mcp-client fibers it
 * maintains. Every mutation is serialized per `serverName` so concurrent calls
 * for one server cannot race; different servers stay independent.
 */
export declare class McpManager extends Service {
    /** The plugin config schema, shared with the loader. */
    static readonly Config: z<Schemastery.ObjectS<{
        storePath: z<string, string>;
    }>, Schemastery.ObjectT<{
        storePath: z<string, string>;
    }>>;
    /** Absolute path to the persisted store file. */
    private readonly storePath;
    /** Authoritative in-memory store: serverName → mount-ready spec. */
    private store;
    /** Live mcp-client fibers currently mounted, keyed by serverName. */
    private readonly mounts;
    /** In-flight mutation promise per serverName (serialization latch). */
    private readonly inFlight;
    /**
     * Per-session preferred server (the composer-dock picker): session id →
     * serverName. In-memory only; it does not survive a restart, and a removed
     * server's preference is dropped with the server.
     */
    private readonly preferences;
    /**
     * @param ctx - the owning Cordis context (carries the tool registry); stored
     *   as `this.ctx` by the Service base and used for live mounts.
     * @param config - resolved plugin config; `storePath` defaults to `~/.dsh`.
     */
    constructor(ctx: Context, config?: Config);
    /** The store file path this instance reads and writes. */
    get storeFilePath(): string;
    /** Load the persisted store into memory without mounting anything yet. */
    load(): Promise<void>;
    /**
     * Load the store and re-mount every stored server, so a persisted set survives
     * a restart. Each mount is awaited; with the default `failOnStartupError:
     * false` a downed server does not reject, its reconnect loop keeps running.
     */
    restore(): Promise<void>;
    /**
     * Register and live-mount a new server.
     * @param input - the server definition to add.
     * @returns the persisted record with its live status.
     * @throws when the `serverName` is already registered, or the spec is invalid.
     */
    add(input: McpServerInput): Promise<McpServerRecord>;
    /**
     * Change a stored server and reconnect it: the old fiber is disposed, the new
     * spec persisted, and a fresh fiber mounted.
     * @param input - the target `serverName` plus the fields to change.
     * @returns the updated record with its live status.
     * @throws when the `serverName` is not registered.
     */
    modify(input: McpServerInput): Promise<McpServerRecord>;
    /**
     * Unmount and delete a stored server.
     * @param serverName - the registered server to remove.
     * @throws when the `serverName` is not registered.
     */
    remove(serverName: string): Promise<void>;
    /**
     * Every stored server with its live connection status.
     * @returns the records, one per stored server.
     */
    list(): McpServerRecord[];
    /**
     * The session's preferred MCP server (the composer-dock picker).
     * @param sessionId - the session whose preference to read.
     * @returns the preferred `serverName`, or undefined when the session set none.
     */
    preferenceFor(sessionId: string): string | undefined;
    /**
     * Set or clear a session's preferred MCP server. Clearing passes null.
     * @param sessionId - the session to set the preference for.
     * @param serverName - a registered server to prefer, or null to clear.
     * @returns the resulting preference (undefined when cleared).
     * @throws when `serverName` names a server that is not registered.
     */
    setPreference(sessionId: string, serverName: string | null): string | undefined;
    /** Mount `spec` and remember its fiber under its `serverName`. */
    private mountOne;
    /** Best-effort persist; a failed write leaves memory authoritative. */
    private persist;
    /** One stored server plus its live status. */
    private record;
    /** Serialize one serverName's mutations without blocking other servers. */
    private withLock;
}
/** The plugin name registered with the Cordis loader. */
export declare const name = "dsh-mcp-plugin";
/**
 * Services required before the manager can register its tools + prompt context.
 * `webServer` is deliberately NOT in this list: the /api/mcp/* routes are an
 * optional no-op when the host has no webserver (non-web profiles), so a hard
 * inject would leave the whole plugin pending there. `registerMcpApi` reads it
 * via `ctx.get` instead.
 */
export declare const inject: string[];
/**
 * Build and register the manager: instantiate the service, register the four
 * control tools (reversibly, on the manager fiber), register the per-session
 * `mcp-server-preference` prompt context, register the /api/mcp/* webserver
 * routes that back the client settings panel and composer-dock picker, and
 * re-mount any persisted servers. The tools register synchronously so they
 * are usable even while a downed server is still reconnecting in the
 * background.
 * @param ctx - the owning context carrying the tool registry.
 * @param config - the resolved plugin config.
 */
export declare function apply(ctx: Context, config?: Config): Promise<void>;
//# sourceMappingURL=host.d.ts.map